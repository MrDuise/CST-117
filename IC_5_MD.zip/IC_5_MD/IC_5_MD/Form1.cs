﻿//Michael Duisenberg
//CST-126
//10-12-20
//This is my own code, except for the logic of finding pi
//this was gotten in class on 10-12-20
//finding Pi logic was simplified to make code neater and more organized




using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IC_5_MD
{
    public partial class approximatePi : Form
    {
        public approximatePi()
        {
            InitializeComponent();
        }

        private void txtEnterNumTerms_TextChanged(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// Button to Calculate PI
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCalcPi_Click(object sender, EventArgs e)
        {
            try
            {
                //Declaring Variables
                int terms = Convert.ToInt32(txtEnterNumTerms.Text);
                double pi = 0;
                double denCount = 1;
               

                for (int counter = 1; counter <= terms; counter++)
                {
                    if (counter % 2 == 0)//if term is even
                        pi -= 4 / denCount;
                    else   
                         pi += 4 / denCount;//if term is odd


                    denCount += 2;//denominator doubles for every term


                }

                lblDisplayPi.Text = "Approximate value of pi after " + terms + " terms is " + pi;
            }
            //catch statement engages when txtEnterNumTerms can't be converted into an int
            catch
            {
                MessageBox.Show("Enter a number please");
                txtEnterNumTerms.Clear();
            }
           
        }
    }
}
