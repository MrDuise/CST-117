﻿namespace IC_5_MD
{
    partial class approximatePi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(approximatePi));
            this.lblNumTerms = new System.Windows.Forms.Label();
            this.txtEnterNumTerms = new System.Windows.Forms.TextBox();
            this.btnCalcPi = new System.Windows.Forms.Button();
            this.lblDisplayPi = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblNumTerms
            // 
            this.lblNumTerms.AutoSize = true;
            this.lblNumTerms.Font = new System.Drawing.Font("MS Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumTerms.Location = new System.Drawing.Point(24, 61);
            this.lblNumTerms.Name = "lblNumTerms";
            this.lblNumTerms.Size = new System.Drawing.Size(197, 17);
            this.lblNumTerms.TabIndex = 0;
            this.lblNumTerms.Text = "Enter Number of Terms";
            // 
            // txtEnterNumTerms
            // 
            this.txtEnterNumTerms.Location = new System.Drawing.Point(252, 60);
            this.txtEnterNumTerms.Name = "txtEnterNumTerms";
            this.txtEnterNumTerms.Size = new System.Drawing.Size(123, 22);
            this.txtEnterNumTerms.TabIndex = 1;
            this.txtEnterNumTerms.TextChanged += new System.EventHandler(this.txtEnterNumTerms_TextChanged);
            // 
            // btnCalcPi
            // 
            this.btnCalcPi.Font = new System.Drawing.Font("MS Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcPi.Location = new System.Drawing.Point(65, 122);
            this.btnCalcPi.Name = "btnCalcPi";
            this.btnCalcPi.Size = new System.Drawing.Size(108, 40);
            this.btnCalcPi.TabIndex = 2;
            this.btnCalcPi.Text = "Calculate ";
            this.btnCalcPi.UseVisualStyleBackColor = true;
            this.btnCalcPi.Click += new System.EventHandler(this.btnCalcPi_Click);
            // 
            // lblDisplayPi
            // 
            this.lblDisplayPi.AutoSize = true;
            this.lblDisplayPi.Location = new System.Drawing.Point(85, 219);
            this.lblDisplayPi.Name = "lblDisplayPi";
            this.lblDisplayPi.Size = new System.Drawing.Size(0, 17);
            this.lblDisplayPi.TabIndex = 3;
            // 
            // approximatePi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(599, 296);
            this.Controls.Add(this.lblDisplayPi);
            this.Controls.Add(this.btnCalcPi);
            this.Controls.Add(this.txtEnterNumTerms);
            this.Controls.Add(this.lblNumTerms);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "approximatePi";
            this.Text = "Approximate Pi";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNumTerms;
        private System.Windows.Forms.TextBox txtEnterNumTerms;
        private System.Windows.Forms.Button btnCalcPi;
        private System.Windows.Forms.Label lblDisplayPi;
    }
}

