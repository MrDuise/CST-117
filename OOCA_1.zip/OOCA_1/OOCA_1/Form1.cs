﻿/*
 * Michael Duisenberg
 * 09-28-20
 * CST-117
 * Bill Hughes
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOCA_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void convertValue_Click(object sender, EventArgs e)
        {
            try
            {
                //define variables
                decimal earthWeight = 0;
                decimal gravAccEarth = Convert.ToDecimal(9.81);
                decimal gravAccMars = Convert.ToDecimal(3.71);
                decimal earthMass = 0;
                //read in the earth weight
                earthWeight = Convert.ToDecimal(txtEarthWeight.Text);
                //find the mass on earth
                earthMass = earthWeight * gravAccEarth;
                //find weight on mars
                decimal marsWeight = ((earthMass * gravAccMars) / 100);
                textMarsWeight.Text = (marsWeight.ToString("#,0.000"));
            }



            catch (Exception exp)
            {
                MessageBox.Show("Exception is: " + exp.Message);
                MessageBox.Show("Please enter a number");
                textMarsWeight.Text = String.Empty;
                txtEarthWeight.Text = String.Empty;

            }
        }

        private void clearText_Click(object sender, EventArgs e)
        {
            textMarsWeight.Text = String.Empty;
            txtEarthWeight.Text = String.Empty;
        }
    }
}
