﻿/*
 * Michael Duisenberg
 * 09-28-20
 * CST-117
 * Bill Hughes
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOCA_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void convertValue_Click(object sender, EventArgs e)
        {
            //the try statement trys to run the following code  
            try
            {
                //define variables
                decimal earthWeight = 0;
                decimal gravAccEarth = Convert.ToDecimal(9.81);
                decimal gravAccMars = Convert.ToDecimal(3.71);
                decimal earthMass = 0;
                //read in the earth weight
                earthWeight = Convert.ToDecimal(txtEarthWeight.Text);
                //find the mass on earth
                earthMass = earthWeight * gravAccEarth;
                //find weight on mars
                decimal marsWeight = ((earthMass * gravAccMars) / 100);
                textMarsWeight.Text = (marsWeight.ToString("#,0.000"));
            }


            //the catch statement runs if there is input in txtEarthWeight that can not be converted to a decimal, such as a letter or word
            catch (Exception exp)
            {
                MessageBox.Show("Exception is: " + exp.Message);
                MessageBox.Show("Please enter a number");
                textMarsWeight.Text = String.Empty;
                txtEarthWeight.Text = String.Empty;

            }
        }

        //the clearText button does just that. it clears the text boxes so the user can keep on running the program without clicking delete. 
        private void clearText_Click(object sender, EventArgs e)
        {
            textMarsWeight.Text = String.Empty;
            txtEarthWeight.Text = String.Empty;
        }
    }
}
