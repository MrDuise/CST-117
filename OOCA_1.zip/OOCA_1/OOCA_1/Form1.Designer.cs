﻿namespace OOCA_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.convertValue = new System.Windows.Forms.Button();
            this.clearText = new System.Windows.Forms.Button();
            this.txtEarthWeight = new System.Windows.Forms.TextBox();
            this.textMarsWeight = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // convertValue
            // 
            this.convertValue.BackColor = System.Drawing.SystemColors.HotTrack;
            this.convertValue.Location = new System.Drawing.Point(125, 275);
            this.convertValue.Name = "convertValue";
            this.convertValue.Size = new System.Drawing.Size(75, 23);
            this.convertValue.TabIndex = 0;
            this.convertValue.Text = "Convert";
            this.convertValue.UseVisualStyleBackColor = false;
            this.convertValue.Click += new System.EventHandler(this.convertValue_Click);
            // 
            // clearText
            // 
            this.clearText.BackColor = System.Drawing.SystemColors.HotTrack;
            this.clearText.Location = new System.Drawing.Point(418, 275);
            this.clearText.Name = "clearText";
            this.clearText.Size = new System.Drawing.Size(94, 23);
            this.clearText.TabIndex = 1;
            this.clearText.Text = "Clear Text";
            this.clearText.UseVisualStyleBackColor = false;
            this.clearText.Click += new System.EventHandler(this.clearText_Click);
            // 
            // txtEarthWeight
            // 
            this.txtEarthWeight.Location = new System.Drawing.Point(418, 77);
            this.txtEarthWeight.Name = "txtEarthWeight";
            this.txtEarthWeight.Size = new System.Drawing.Size(123, 22);
            this.txtEarthWeight.TabIndex = 2;
            // 
            // textMarsWeight
            // 
            this.textMarsWeight.Location = new System.Drawing.Point(418, 187);
            this.textMarsWeight.Name = "textMarsWeight";
            this.textMarsWeight.Size = new System.Drawing.Size(123, 22);
            this.textMarsWeight.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(122, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(176, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Enter your weight on Earth";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(122, 169);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Weight on Mars";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textMarsWeight);
            this.Controls.Add(this.txtEarthWeight);
            this.Controls.Add(this.clearText);
            this.Controls.Add(this.convertValue);
            this.Name = "Form1";
            this.Text = "Earth/Mars weight converter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button convertValue;
        private System.Windows.Forms.Button clearText;
        private System.Windows.Forms.TextBox txtEarthWeight;
        private System.Windows.Forms.TextBox textMarsWeight;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

