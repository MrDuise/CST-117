﻿//Michael Duiseberg
//11-9-20
//CST-117
//In Class Assignment 7
//Driver code
//This code is my own 



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IC_7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMethods_Click(object sender, EventArgs e)
        {
            // first method

            int firstInt = 12;
            int secondInt = 24;

            Methods firstMethod = new Methods();

            int totalSum = firstMethod.sumInt(firstInt, secondInt);

            lblSum.Text = "Total is: " + totalSum.ToString();



            //second method

            double first = 5, second = 6, third = 7, fourth = 8, firth = 9;

            Methods secondMethod = new Methods();

            double avgSum = secondMethod.avgDouble(first, second, third, fourth, firth);

            lblAverage.Text = "Average is: " + avgSum.ToString();


            //third method
            int randAverge = secondMethod.sumRand();

            lblRanNumSum.Text = "The sum of the random numbers is: " + randAverge.ToString();


            //4th method
            int a = 5, b = 6, c = 7;

            bool threeAverage = secondMethod.threeNumSum(a, b, c);

            lblThreeNum.Text = "The sum of the 3 numbers are divisable by 3: " + threeAverage.ToString();


            //5th method
            string firstWord = "Super";
            string secondWord = "Cat";

            string longWord = secondMethod.lessChar(firstWord, secondWord);

            lblLessChar.Text = "The longest word between " + firstWord + " and " + secondWord + " is: " + longWord;

            
            //6th method
            bool firstBool = true, secondBool = false;

            bool result = secondMethod.compareBools(firstBool, secondBool);

            lblBoolCompare.Text = "Did the two Bools have the same value: " + result.ToString();


            //7th method
            double testDouble = 5.25D;
            int testInt = 5;
            double newResult;

            newResult =  secondMethod.intDoubleMultiply(testInt, testDouble);

            lblDoubleIntProduct.Text = "The result of multiplying " + testDouble + " and " + testInt + " is: " + newResult; 
            
        }
    }
}
