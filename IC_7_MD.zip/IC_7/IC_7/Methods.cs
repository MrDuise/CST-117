﻿//Michael Duiseberg
//11-9-20
//CST-117
//In Class Assignment 7
//Method class
//This class is a group of methods that all output different varibles. The point of this code is practice with both writing a class
//and with writing methods
//This code is my own 





using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IC_7
{
    class Methods
    {
        //---------------------------
        //first method

        /// <summary>
        /// return the sum of two ints
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        public int sumInt(int a, int b)
        {
            return a + b;
        }

        /// <summary>
        /// takes 5 doubles and returns the average of them
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <param name="c"></param>
        /// <param name="d"></param>
        /// <param name="e"></param>
        /// <returns></returns>
        public double avgDouble(double a, double b, double c, double d, double e)
        { 
            return (a + b + c + d + e) / 5;
        }


        /// <summary>
        /// creates 2 random numbers between 1 and 100, then adds them together and returns the sum
        /// </summary>
        /// <returns></returns>
        public int sumRand()
        {
            
            Random first = new Random();
            System.Threading.Thread.Sleep(100);
            Random second = new Random();
            int a = first.Next(1, 100);
            int b = second.Next(1, 100);

            int result = a + b;
            return result;
        }

        /// <summary>
        /// returns either true if the sum of the three numbers is divisible by 3, false if it doesn't
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <param name="c"></param>
        /// <returns></returns>
        public bool threeNumSum(int a, int b, int c)
        {
            int sum = a + b + c;
            

            if ((sum % 3) == 0)
                return true;
            else
                return false;
        }


        /// <summary>
        /// compares 2 strings and returns the longer one
        /// </summary>
        /// <param name="first"></param>
        /// <param name="second"></param>
        /// <returns></returns>
        public string lessChar(string first, string second)
        {
            string longestString = "i";

            if (first.Length > second.Length)
                longestString = first;
            else
                longestString = second;
            return longestString; 
        }

        /// <summary>
        /// compares two bool variables
        /// </summary>
        /// <param name="first"></param>
        /// <param name="second"></param>
        /// <returns></returns>
        public bool compareBools(bool first, bool second)
        {
            if (first == second)
                return true;
            else
                return false;

        }

        /// <summary>
        /// takes a int and a double and multiplies them together, then returns the result
        /// </summary>
        /// <param name="first"></param>
        /// <param name="second"></param>
        /// <returns></returns>
        public double intDoubleMultiply(int first, double second)
        {
            return Convert.ToDouble(first) * second;
        }



    }

}
