﻿namespace IC_7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSum = new System.Windows.Forms.Label();
            this.lblAverage = new System.Windows.Forms.Label();
            this.lblRanNumSum = new System.Windows.Forms.Label();
            this.lblThreeNum = new System.Windows.Forms.Label();
            this.lblLessChar = new System.Windows.Forms.Label();
            this.lblBoolCompare = new System.Windows.Forms.Label();
            this.lblDoubleIntProduct = new System.Windows.Forms.Label();
            this.btnMethods = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblSum
            // 
            this.lblSum.AutoSize = true;
            this.lblSum.Location = new System.Drawing.Point(12, 20);
            this.lblSum.Name = "lblSum";
            this.lblSum.Size = new System.Drawing.Size(123, 17);
            this.lblSum.TabIndex = 0;
            this.lblSum.Text = "Sum of 2 numbers";
            // 
            // lblAverage
            // 
            this.lblAverage.AutoSize = true;
            this.lblAverage.Location = new System.Drawing.Point(12, 67);
            this.lblAverage.Name = "lblAverage";
            this.lblAverage.Size = new System.Drawing.Size(148, 17);
            this.lblAverage.TabIndex = 1;
            this.lblAverage.Text = "Average of 5 numbers";
            // 
            // lblRanNumSum
            // 
            this.lblRanNumSum.AutoSize = true;
            this.lblRanNumSum.Location = new System.Drawing.Point(12, 116);
            this.lblRanNumSum.Name = "lblRanNumSum";
            this.lblRanNumSum.Size = new System.Drawing.Size(175, 17);
            this.lblRanNumSum.TabIndex = 2;
            this.lblRanNumSum.Text = "Sum of 2 random numbers";
            // 
            // lblThreeNum
            // 
            this.lblThreeNum.AutoSize = true;
            this.lblThreeNum.Location = new System.Drawing.Point(12, 160);
            this.lblThreeNum.Name = "lblThreeNum";
            this.lblThreeNum.Size = new System.Drawing.Size(174, 17);
            this.lblThreeNum.TabIndex = 3;
            this.lblThreeNum.Text = "Is the Sum Divisable by 3?";
            // 
            // lblLessChar
            // 
            this.lblLessChar.AutoSize = true;
            this.lblLessChar.Location = new System.Drawing.Point(12, 217);
            this.lblLessChar.Name = "lblLessChar";
            this.lblLessChar.Size = new System.Drawing.Size(97, 17);
            this.lblLessChar.TabIndex = 4;
            this.lblLessChar.Text = "Longest Word";
            // 
            // lblBoolCompare
            // 
            this.lblBoolCompare.AutoSize = true;
            this.lblBoolCompare.Location = new System.Drawing.Point(12, 266);
            this.lblBoolCompare.Name = "lblBoolCompare";
            this.lblBoolCompare.Size = new System.Drawing.Size(247, 17);
            this.lblBoolCompare.TabIndex = 5;
            this.lblBoolCompare.Text = "Compare the value of 2 bool variables";
            // 
            // lblDoubleIntProduct
            // 
            this.lblDoubleIntProduct.AutoSize = true;
            this.lblDoubleIntProduct.Location = new System.Drawing.Point(12, 312);
            this.lblDoubleIntProduct.Name = "lblDoubleIntProduct";
            this.lblDoubleIntProduct.Size = new System.Drawing.Size(229, 17);
            this.lblDoubleIntProduct.TabIndex = 6;
            this.lblDoubleIntProduct.Text = "The product of an Int and a Double";
            // 
            // btnMethods
            // 
            this.btnMethods.Location = new System.Drawing.Point(24, 404);
            this.btnMethods.Name = "btnMethods";
            this.btnMethods.Size = new System.Drawing.Size(136, 23);
            this.btnMethods.TabIndex = 7;
            this.btnMethods.Text = "Display Values";
            this.btnMethods.UseVisualStyleBackColor = true;
            this.btnMethods.Click += new System.EventHandler(this.btnMethods_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnMethods);
            this.Controls.Add(this.lblDoubleIntProduct);
            this.Controls.Add(this.lblBoolCompare);
            this.Controls.Add(this.lblLessChar);
            this.Controls.Add(this.lblThreeNum);
            this.Controls.Add(this.lblRanNumSum);
            this.Controls.Add(this.lblAverage);
            this.Controls.Add(this.lblSum);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSum;
        private System.Windows.Forms.Label lblAverage;
        private System.Windows.Forms.Label lblRanNumSum;
        private System.Windows.Forms.Label lblThreeNum;
        private System.Windows.Forms.Label lblLessChar;
        private System.Windows.Forms.Label lblBoolCompare;
        private System.Windows.Forms.Label lblDoubleIntProduct;
        private System.Windows.Forms.Button btnMethods;
    }
}

