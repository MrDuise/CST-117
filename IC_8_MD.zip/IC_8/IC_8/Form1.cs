﻿//Michael Duisenberg
//11-10-20
//CST-117
//In Class Assignment 8
//This code allows the user to enter the number of fat grams and the number of carbs, then return the number of calories using a class
//This is all my own code




using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IC_8
{
    public partial class calorieConverter : Form
    {
        public calorieConverter()
        {
            InitializeComponent();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            try
            {
                //create instance of class
                Converter calorie = new Converter();

                //feed user input into a variable
                double calFromFat = calorie.FatCalories(Convert.ToDouble(txtFat.Text));

                //output to screen
                lblCalFromFat.Text = "The number of calories you would get from that many grams of fat is: " + calFromFat + " calories";

                //feed user input into variable
                double calFromCarbs = calorie.CarbCalories(Convert.ToDouble(txtCarbs.Text));

                //output to screen
                lblCalFromCarbs.Text = "The number of calories you would get from that many carbs is: " + calFromCarbs + " calories";

            }

            catch
            {
                //if user does not enter anything into the textboxes
                MessageBox.Show("Please enter a number");
            }
          


        }
    }
}
