﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IC_8
{
    class Converter
    {
        /// <summary>
        /// This method takes in the number of fat grams and returns the number of calories you would get from them
        /// </summary>
        /// <param name="numFat"></param>
        /// <returns></returns>
        public double FatCalories(double numFat)
        {
            double calFromFat = numFat * 9;

            return calFromFat;
        }

        /// <summary>
        /// this method takes in the number of carbs and returns the number of calories you would get from them
        /// </summary>
        /// <param name="numCarbs"></param>
        /// <returns></returns>
        public double CarbCalories(double numCarbs)
        {
            double calFromCarbs = numCarbs * 4;

            return calFromCarbs;
        }
    }
}
