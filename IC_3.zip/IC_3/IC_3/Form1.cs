﻿/* 
 * Michael Duisenberg
 * 09-21-20
 * CST-117
 * Proffecor Huges
*/





using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IC_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lbsInput_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void convertValue_Click(object sender, EventArgs e)
        {
            //define variables
            decimal earthWeight = 0;
            decimal gravAccEarth = Convert.ToDecimal(9.81);
            decimal gravAccMars = Convert.ToDecimal(3.71);
            decimal earthMass = 0;
            //read in the earth weight
            earthWeight = Convert.ToDecimal(txtEarthWeight.Text);
            //find the mass on earth
            earthMass = earthWeight * gravAccEarth;
            //find weight on mars
            textMarsWeight.Text = ((earthMass * gravAccMars) / 100).ToString();
      
        }
    }
}
