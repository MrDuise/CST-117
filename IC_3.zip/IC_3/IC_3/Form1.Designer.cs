﻿namespace IC_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.txtEarthWeight = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.textMarsWeight = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.convertValue = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(42, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(206, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter your weight on Earth";
            // 
            // txtEarthWeight
            // 
            this.txtEarthWeight.Location = new System.Drawing.Point(277, 81);
            this.txtEarthWeight.Name = "txtEarthWeight";
            this.txtEarthWeight.Size = new System.Drawing.Size(142, 22);
            this.txtEarthWeight.TabIndex = 1;
            this.txtEarthWeight.TextChanged += new System.EventHandler(this.lbsInput_TextChanged);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // textMarsWeight
            // 
            this.textMarsWeight.Location = new System.Drawing.Point(277, 149);
            this.textMarsWeight.Name = "textMarsWeight";
            this.textMarsWeight.Size = new System.Drawing.Size(142, 22);
            this.textMarsWeight.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(42, 152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 24);
            this.label2.TabIndex = 4;
            this.label2.Text = "Weight on Mars";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // convertValue
            // 
            this.convertValue.BackColor = System.Drawing.SystemColors.Highlight;
            this.convertValue.Location = new System.Drawing.Point(46, 235);
            this.convertValue.Name = "convertValue";
            this.convertValue.Size = new System.Drawing.Size(75, 23);
            this.convertValue.TabIndex = 5;
            this.convertValue.Text = "Convert";
            this.convertValue.UseVisualStyleBackColor = false;
            this.convertValue.Click += new System.EventHandler(this.convertValue_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(521, 450);
            this.Controls.Add(this.convertValue);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textMarsWeight);
            this.Controls.Add(this.txtEarthWeight);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Pounds to Kiligrams";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtEarthWeight;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox textMarsWeight;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button convertValue;
    }
}

