﻿//Michael Duisenberg
//11-30-20
//Out of Class Assignment 5
//This is the main form
//This is my own code


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOCA_5
{
    public partial class formMain : Form
    {
        public formMain()
        {
            InitializeComponent();
        }

        public static formMain staticVar = null;

        private void btnLuckyNumber_Click(object sender, EventArgs e)
        {
            staticVar = this;
            ResultsForm displayResults = new ResultsForm();
            displayResults.Show();
        }
    }
}
