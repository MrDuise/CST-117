﻿namespace OOCA_5
{
    partial class formMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBirthYear = new System.Windows.Forms.TextBox();
            this.txtBirthDay = new System.Windows.Forms.TextBox();
            this.btnLuckyNumber = new System.Windows.Forms.Button();
            this.cmbBirthMonth = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter Your Birth Year:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Enter Your Birth Month: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Enter Your Birth Day: ";
            // 
            // txtBirthYear
            // 
            this.txtBirthYear.Location = new System.Drawing.Point(205, 28);
            this.txtBirthYear.Name = "txtBirthYear";
            this.txtBirthYear.Size = new System.Drawing.Size(100, 22);
            this.txtBirthYear.TabIndex = 4;
            // 
            // txtBirthDay
            // 
            this.txtBirthDay.Location = new System.Drawing.Point(205, 133);
            this.txtBirthDay.Name = "txtBirthDay";
            this.txtBirthDay.Size = new System.Drawing.Size(100, 22);
            this.txtBirthDay.TabIndex = 6;
            // 
            // btnLuckyNumber
            // 
            this.btnLuckyNumber.Location = new System.Drawing.Point(33, 226);
            this.btnLuckyNumber.Name = "btnLuckyNumber";
            this.btnLuckyNumber.Size = new System.Drawing.Size(272, 30);
            this.btnLuckyNumber.TabIndex = 8;
            this.btnLuckyNumber.Text = "Get Your Lucky Number";
            this.btnLuckyNumber.UseVisualStyleBackColor = true;
            this.btnLuckyNumber.Click += new System.EventHandler(this.btnLuckyNumber_Click);
            // 
            // cmbBirthMonth
            // 
            this.cmbBirthMonth.FormattingEnabled = true;
            this.cmbBirthMonth.Items.AddRange(new object[] {
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"});
            this.cmbBirthMonth.Location = new System.Drawing.Point(196, 74);
            this.cmbBirthMonth.Name = "cmbBirthMonth";
            this.cmbBirthMonth.Size = new System.Drawing.Size(121, 24);
            this.cmbBirthMonth.TabIndex = 9;
            // 
            // formMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(361, 324);
            this.Controls.Add(this.cmbBirthMonth);
            this.Controls.Add(this.btnLuckyNumber);
            this.Controls.Add(this.txtBirthDay);
            this.Controls.Add(this.txtBirthYear);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "formMain";
            this.Text = "Find Your Lucky Number";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnLuckyNumber;
        public System.Windows.Forms.TextBox txtBirthYear;
        public System.Windows.Forms.TextBox txtBirthDay;
        private System.Windows.Forms.ComboBox cmbBirthMonth;
    }
}

