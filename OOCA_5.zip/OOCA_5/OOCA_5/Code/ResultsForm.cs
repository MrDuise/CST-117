﻿//Michael Duisenberg
//11-30-20
//Out of Class Assignment 5
//This is the results form
//This is my own code

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOCA_5
{
    public partial class ResultsForm : Form
    {
        public ResultsForm()
        {
            InitializeComponent();
        }

        private void ResultsForm_Load(object sender, EventArgs e)
        {
            int birthYear = Convert.ToInt32(formMain.staticVar.txtBirthYear.Text);

            int result;
            Random luckyNum = new Random();
            if (birthYear > 1920 && birthYear < 1970)
            {
               result = luckyNum.Next(25);
            }
            else if(birthYear > 1970 && birthYear < 2000)
            {
               result = luckyNum.Next(26, 50);
            }
            else
            {
               result = luckyNum.Next(51, 100);
            }
            
            lblLuckyNumberResult.Text = result.ToString();
        }
    }
}
