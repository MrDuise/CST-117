﻿namespace Inventory_Project
{
    partial class mainScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inventoryView = new System.Windows.Forms.DataGridView();
            this.selectRow = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.postion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.picture = new System.Windows.Forms.DataGridViewImageColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inStock = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numInStock = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateLastBought = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.editItem = new System.Windows.Forms.Button();
            this.deleteItem = new System.Windows.Forms.Button();
            this.searchForItem = new System.Windows.Forms.Button();
            this.reorderList = new System.Windows.Forms.Button();
            this.addItem = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryView)).BeginInit();
            this.SuspendLayout();
            // 
            // inventoryView
            // 
            this.inventoryView.AllowDrop = true;
            this.inventoryView.AllowUserToResizeColumns = false;
            this.inventoryView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.inventoryView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.selectRow,
            this.postion,
            this.itemID,
            this.picture,
            this.name,
            this.description,
            this.price,
            this.inStock,
            this.numInStock,
            this.dateLastBought});
            this.inventoryView.Location = new System.Drawing.Point(12, 3);
            this.inventoryView.Name = "inventoryView";
            this.inventoryView.RowHeadersWidth = 51;
            this.inventoryView.RowTemplate.Height = 24;
            this.inventoryView.Size = new System.Drawing.Size(1326, 419);
            this.inventoryView.TabIndex = 3;
            this.inventoryView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // selectRow
            // 
            this.selectRow.HeaderText = "";
            this.selectRow.MinimumWidth = 6;
            this.selectRow.Name = "selectRow";
            this.selectRow.Width = 125;
            // 
            // postion
            // 
            this.postion.HeaderText = "Postion";
            this.postion.MinimumWidth = 6;
            this.postion.Name = "postion";
            this.postion.Width = 125;
            // 
            // itemID
            // 
            this.itemID.HeaderText = "Item ID";
            this.itemID.MinimumWidth = 6;
            this.itemID.Name = "itemID";
            this.itemID.Width = 125;
            // 
            // picture
            // 
            this.picture.HeaderText = "Picture";
            this.picture.MinimumWidth = 6;
            this.picture.Name = "picture";
            this.picture.Width = 125;
            // 
            // name
            // 
            this.name.HeaderText = "Name";
            this.name.MinimumWidth = 6;
            this.name.Name = "name";
            this.name.Width = 125;
            // 
            // description
            // 
            this.description.HeaderText = "Item Description";
            this.description.MinimumWidth = 6;
            this.description.Name = "description";
            this.description.Width = 125;
            // 
            // price
            // 
            this.price.HeaderText = "Price";
            this.price.MinimumWidth = 6;
            this.price.Name = "price";
            this.price.Width = 125;
            // 
            // inStock
            // 
            this.inStock.HeaderText = "In Stock";
            this.inStock.MinimumWidth = 6;
            this.inStock.Name = "inStock";
            this.inStock.Width = 125;
            // 
            // numInStock
            // 
            this.numInStock.HeaderText = "Number In Stock";
            this.numInStock.MinimumWidth = 6;
            this.numInStock.Name = "numInStock";
            this.numInStock.Width = 125;
            // 
            // dateLastBought
            // 
            this.dateLastBought.HeaderText = "Date Last Bought";
            this.dateLastBought.MinimumWidth = 6;
            this.dateLastBought.Name = "dateLastBought";
            this.dateLastBought.Width = 125;
            // 
            // editItem
            // 
            this.editItem.Location = new System.Drawing.Point(943, 471);
            this.editItem.Name = "editItem";
            this.editItem.Size = new System.Drawing.Size(93, 23);
            this.editItem.TabIndex = 4;
            this.editItem.Text = "EDIT";
            this.editItem.UseVisualStyleBackColor = true;
            // 
            // deleteItem
            // 
            this.deleteItem.Location = new System.Drawing.Point(1100, 472);
            this.deleteItem.Name = "deleteItem";
            this.deleteItem.Size = new System.Drawing.Size(87, 24);
            this.deleteItem.TabIndex = 5;
            this.deleteItem.Text = "DELETE";
            this.deleteItem.UseVisualStyleBackColor = true;
            // 
            // searchForItem
            // 
            this.searchForItem.Location = new System.Drawing.Point(803, 472);
            this.searchForItem.Name = "searchForItem";
            this.searchForItem.Size = new System.Drawing.Size(82, 23);
            this.searchForItem.TabIndex = 6;
            this.searchForItem.Text = "SEARCH";
            this.searchForItem.UseVisualStyleBackColor = true;
            this.searchForItem.Click += new System.EventHandler(this.button3_Click);
            // 
            // reorderList
            // 
            this.reorderList.Location = new System.Drawing.Point(1226, 470);
            this.reorderList.Name = "reorderList";
            this.reorderList.Size = new System.Drawing.Size(98, 23);
            this.reorderList.TabIndex = 7;
            this.reorderList.Text = "REORDER";
            this.reorderList.UseVisualStyleBackColor = true;
            // 
            // addItem
            // 
            this.addItem.Location = new System.Drawing.Point(667, 471);
            this.addItem.Name = "addItem";
            this.addItem.Size = new System.Drawing.Size(90, 22);
            this.addItem.TabIndex = 8;
            this.addItem.Text = "ADD";
            this.addItem.UseVisualStyleBackColor = true;
            // 
            // mainScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1350, 515);
            this.Controls.Add(this.addItem);
            this.Controls.Add(this.reorderList);
            this.Controls.Add(this.searchForItem);
            this.Controls.Add(this.deleteItem);
            this.Controls.Add(this.editItem);
            this.Controls.Add(this.inventoryView);
            this.Name = "mainScreen";
            this.Text = "Inventory Screen";
            ((System.ComponentModel.ISupportInitialize)(this.inventoryView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridView inventoryView;
        private System.Windows.Forms.Button editItem;
        private System.Windows.Forms.Button deleteItem;
        private System.Windows.Forms.Button searchForItem;
        private System.Windows.Forms.Button reorderList;
        private System.Windows.Forms.Button addItem;
        private System.Windows.Forms.DataGridViewCheckBoxColumn selectRow;
        private System.Windows.Forms.DataGridViewTextBoxColumn postion;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemID;
        private System.Windows.Forms.DataGridViewImageColumn picture;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn description;
        private System.Windows.Forms.DataGridViewTextBoxColumn price;
        private System.Windows.Forms.DataGridViewTextBoxColumn inStock;
        private System.Windows.Forms.DataGridViewTextBoxColumn numInStock;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateLastBought;
    }
}

