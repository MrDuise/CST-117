﻿namespace Inventory_Project
{
    partial class addItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addItemsBox = new System.Windows.Forms.GroupBox();
            this.addItemButton = new System.Windows.Forms.Button();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.addStockNum = new System.Windows.Forms.TextBox();
            this.addDiscription = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.addName = new System.Windows.Forms.TextBox();
            this.addStockTF = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.addItemId = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.addPrice = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.addItemsBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // addItemsBox
            // 
            this.addItemsBox.Controls.Add(this.addItemButton);
            this.addItemsBox.Controls.Add(this.textBox10);
            this.addItemsBox.Controls.Add(this.addStockNum);
            this.addItemsBox.Controls.Add(this.addDiscription);
            this.addItemsBox.Controls.Add(this.label9);
            this.addItemsBox.Controls.Add(this.addName);
            this.addItemsBox.Controls.Add(this.addStockTF);
            this.addItemsBox.Controls.Add(this.label3);
            this.addItemsBox.Controls.Add(this.addItemId);
            this.addItemsBox.Controls.Add(this.label6);
            this.addItemsBox.Controls.Add(this.label7);
            this.addItemsBox.Controls.Add(this.label2);
            this.addItemsBox.Controls.Add(this.addPrice);
            this.addItemsBox.Controls.Add(this.label1);
            this.addItemsBox.Controls.Add(this.label5);
            this.addItemsBox.Location = new System.Drawing.Point(254, 29);
            this.addItemsBox.Name = "addItemsBox";
            this.addItemsBox.Size = new System.Drawing.Size(338, 486);
            this.addItemsBox.TabIndex = 0;
            this.addItemsBox.TabStop = false;
            this.addItemsBox.Text = "Add Items";
            // 
            // addItemButton
            // 
            this.addItemButton.Location = new System.Drawing.Point(171, 434);
            this.addItemButton.Name = "addItemButton";
            this.addItemButton.Size = new System.Drawing.Size(112, 31);
            this.addItemButton.TabIndex = 21;
            this.addItemButton.Text = "Add Item";
            this.addItemButton.UseVisualStyleBackColor = true;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(171, 81);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(128, 22);
            this.textBox10.TabIndex = 20;
            // 
            // addStockNum
            // 
            this.addStockNum.Location = new System.Drawing.Point(171, 349);
            this.addStockNum.Name = "addStockNum";
            this.addStockNum.Size = new System.Drawing.Size(128, 22);
            this.addStockNum.TabIndex = 13;
            // 
            // addDiscription
            // 
            this.addDiscription.Location = new System.Drawing.Point(171, 189);
            this.addDiscription.Name = "addDiscription";
            this.addDiscription.Size = new System.Drawing.Size(128, 22);
            this.addDiscription.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(50, 192);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 17);
            this.label9.TabIndex = 9;
            this.label9.Text = "Discription";
            // 
            // addName
            // 
            this.addName.Location = new System.Drawing.Point(171, 132);
            this.addName.Name = "addName";
            this.addName.Size = new System.Drawing.Size(128, 22);
            this.addName.TabIndex = 19;
            // 
            // addStockTF
            // 
            this.addStockTF.Location = new System.Drawing.Point(171, 303);
            this.addStockTF.Name = "addStockTF";
            this.addStockTF.Size = new System.Drawing.Size(128, 22);
            this.addStockTF.TabIndex = 16;
            this.addStockTF.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(50, 349);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Number In Stock";
            // 
            // addItemId
            // 
            this.addItemId.Location = new System.Drawing.Point(171, 36);
            this.addItemId.Name = "addItemId";
            this.addItemId.Size = new System.Drawing.Size(128, 22);
            this.addItemId.TabIndex = 11;
            this.addItemId.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(48, 303);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "In Stock or Not";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(48, 245);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 17);
            this.label7.TabIndex = 7;
            this.label7.Text = "Price";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Item ID";
            // 
            // addPrice
            // 
            this.addPrice.Location = new System.Drawing.Point(171, 245);
            this.addPrice.Name = "addPrice";
            this.addPrice.Size = new System.Drawing.Size(128, 22);
            this.addPrice.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Picture";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(50, 132);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 17);
            this.label5.TabIndex = 5;
            this.label5.Text = "Name";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // addItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(927, 538);
            this.Controls.Add(this.addItemsBox);
            this.Name = "addItem";
            this.Text = "Add to Inventory";
            this.addItemsBox.ResumeLayout(false);
            this.addItemsBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox addItemsBox;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox addName;
        private System.Windows.Forms.TextBox addItemId;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox addDiscription;
        private System.Windows.Forms.TextBox addStockNum;
        private System.Windows.Forms.TextBox addStockTF;
        private System.Windows.Forms.TextBox addPrice;
        private System.Windows.Forms.Button addItemButton;
    }
}