﻿/*Michael Duisenberg
 * CST-117 
 * Search inventory screen
 * 10-03-20
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inventory_Project
{
    public partial class searchInventory : Form
    {
        public searchInventory()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
