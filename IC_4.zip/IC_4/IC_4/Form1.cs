﻿/*
 * Michal Duisenberg
 * CST-117
 * 10-5-20
 * In Class Assignment 4
*/

//This code allows the user to enter in a time in seconds, and it will be converted into minutes, hours, and seconds




using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace IC_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtElapsedSeconds_TextChanged(object sender, EventArgs e)
        {

        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int inputSeconds = Convert.ToInt32(txtElapsedSeconds.Text);
                int answerMinutes = 0;
                int answerHours = 0;
                int answerDays = 0;
                int remainSeconds = 0;
                int remainMinutes = 0;
                int remainHours = 0;


                if ((inputSeconds >= 60) & (inputSeconds < 3600))
                {
                    answerMinutes = inputSeconds / 60;
                    lblTimeOutput.Text = "The number of minutes equals: " + answerMinutes;

                    //calculate the remaining seconds after minutes have been displayed
                    remainSeconds = inputSeconds - (answerMinutes * 60);
                    lblRemainSeconds.Text = "The number of left over seconds is: " + remainSeconds;





                }
                else if ((inputSeconds >= 3600) & (inputSeconds < 86400))
                {

                    //convert to hours
                    answerHours = inputSeconds / 3600;
                    answerMinutes = inputSeconds / 60;
                    lblTimeOutput.Text = "The number of hours equals: " + answerHours;
                    //displays the remaining number of seconds and minutes, even if the number is 0
                    remainMinutes = (inputSeconds / 60) - (answerHours * 60);
                    lblRemainMinutes.Text = "The number of left over minutes is: " + remainMinutes;
                    remainSeconds = inputSeconds - (answerMinutes * 60);
                    lblRemainSeconds.Text = "The number of left over seconds is: " + remainSeconds;



                }
                else if (inputSeconds >= 86400)
                {

                    answerDays = inputSeconds / 86400;
                    answerHours = inputSeconds / 3600;
                    answerMinutes = inputSeconds / 60;
                    lblTimeOutput.Text = "The number of days equals: " + answerDays;
                    //displays the remaining number of hours, seconds, and minutes, even if the number is 0
                    remainHours = (inputSeconds / 3600) - (answerDays * 24);
                    lblRemainHours.Text = "The number of left over hours is: " + remainHours;
                    remainMinutes = (inputSeconds / 60) - (answerHours * 60);
                    lblRemainMinutes.Text = "The number of left over minutes is: " + remainMinutes;
                    remainSeconds = inputSeconds - (answerMinutes * 60);
                    lblRemainSeconds.Text = "The number of left over seconds is: " + remainSeconds;
                }
                
            }


            catch (FormatException exp)
            {
                MessageBox.Show("Exception is: " + exp.Message);
                MessageBox.Show("Please enter a number");
                txtElapsedSeconds.Text = String.Empty;
            }



        }
        
        

       

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }

}
