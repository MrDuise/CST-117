﻿namespace IC_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.txtElapsedSeconds = new System.Windows.Forms.TextBox();
            this.lblTimeOutput = new System.Windows.Forms.Label();
            this.bttnFindOut = new System.Windows.Forms.Button();
            this.lblRemainSeconds = new System.Windows.Forms.Label();
            this.lblRemainMinutes = new System.Windows.Forms.Label();
            this.lblRemainHours = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label1.Location = new System.Drawing.Point(56, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Number of Seconds Elapsed";
            // 
            // txtElapsedSeconds
            // 
            this.txtElapsedSeconds.Font = new System.Drawing.Font("Monotype Corsiva", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtElapsedSeconds.Location = new System.Drawing.Point(278, 71);
            this.txtElapsedSeconds.Name = "txtElapsedSeconds";
            this.txtElapsedSeconds.Size = new System.Drawing.Size(198, 27);
            this.txtElapsedSeconds.TabIndex = 1;
            this.txtElapsedSeconds.TextChanged += new System.EventHandler(this.txtElapsedSeconds_TextChanged);
            // 
            // lblTimeOutput
            // 
            this.lblTimeOutput.AutoSize = true;
            this.lblTimeOutput.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimeOutput.Location = new System.Drawing.Point(294, 134);
            this.lblTimeOutput.Name = "lblTimeOutput";
            this.lblTimeOutput.Size = new System.Drawing.Size(0, 24);
            this.lblTimeOutput.TabIndex = 2;
            // 
            // bttnFindOut
            // 
            this.bttnFindOut.BackColor = System.Drawing.SystemColors.ControlText;
            this.bttnFindOut.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.bttnFindOut.Location = new System.Drawing.Point(80, 310);
            this.bttnFindOut.Name = "bttnFindOut";
            this.bttnFindOut.Size = new System.Drawing.Size(119, 40);
            this.bttnFindOut.TabIndex = 3;
            this.bttnFindOut.Text = "Convert";
            this.bttnFindOut.UseVisualStyleBackColor = false;
            this.bttnFindOut.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblRemainSeconds
            // 
            this.lblRemainSeconds.AutoSize = true;
            this.lblRemainSeconds.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRemainSeconds.Location = new System.Drawing.Point(294, 168);
            this.lblRemainSeconds.Name = "lblRemainSeconds";
            this.lblRemainSeconds.Size = new System.Drawing.Size(0, 24);
            this.lblRemainSeconds.TabIndex = 9;
            // 
            // lblRemainMinutes
            // 
            this.lblRemainMinutes.AutoSize = true;
            this.lblRemainMinutes.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRemainMinutes.Location = new System.Drawing.Point(294, 207);
            this.lblRemainMinutes.Name = "lblRemainMinutes";
            this.lblRemainMinutes.Size = new System.Drawing.Size(0, 24);
            this.lblRemainMinutes.TabIndex = 10;
            // 
            // lblRemainHours
            // 
            this.lblRemainHours.AutoSize = true;
            this.lblRemainHours.Font = new System.Drawing.Font("Monotype Corsiva", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRemainHours.Location = new System.Drawing.Point(294, 252);
            this.lblRemainHours.Name = "lblRemainHours";
            this.lblRemainHours.Size = new System.Drawing.Size(0, 24);
            this.lblRemainHours.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1020, 450);
            this.Controls.Add(this.lblRemainHours);
            this.Controls.Add(this.lblRemainMinutes);
            this.Controls.Add(this.lblRemainSeconds);
            this.Controls.Add(this.bttnFindOut);
            this.Controls.Add(this.lblTimeOutput);
            this.Controls.Add(this.txtElapsedSeconds);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "In Class Assignment 4";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtElapsedSeconds;
        private System.Windows.Forms.Label lblTimeOutput;
        private System.Windows.Forms.Button bttnFindOut;
        private System.Windows.Forms.Label lblRemainSeconds;
        private System.Windows.Forms.Label lblRemainMinutes;
        private System.Windows.Forms.Label lblRemainHours;
    }
}

