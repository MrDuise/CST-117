﻿namespace OOCA_4_Tic_Tac_Toe
{
    partial class Tic_Tac_Toe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTopLeft = new System.Windows.Forms.Label();
            this.lblTopRight = new System.Windows.Forms.Label();
            this.lblMiddleLeft = new System.Windows.Forms.Label();
            this.lblMiddleMiddle = new System.Windows.Forms.Label();
            this.lblMiddleRight = new System.Windows.Forms.Label();
            this.lblBottomLeft = new System.Windows.Forms.Label();
            this.lblBottomMiddle = new System.Windows.Forms.Label();
            this.lblBottomRight = new System.Windows.Forms.Label();
            this.lblTopMiddle = new System.Windows.Forms.Label();
            this.btnNewGame = new System.Windows.Forms.Button();
            this.lblGameResult = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTopLeft
            // 
            this.lblTopLeft.AutoSize = true;
            this.lblTopLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTopLeft.Location = new System.Drawing.Point(147, 9);
            this.lblTopLeft.MinimumSize = new System.Drawing.Size(5, 5);
            this.lblTopLeft.Name = "lblTopLeft";
            this.lblTopLeft.Size = new System.Drawing.Size(5, 91);
            this.lblTopLeft.TabIndex = 0;
            this.lblTopLeft.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTopRight
            // 
            this.lblTopRight.AutoSize = true;
            this.lblTopRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTopRight.Location = new System.Drawing.Point(372, 9);
            this.lblTopRight.Name = "lblTopRight";
            this.lblTopRight.Size = new System.Drawing.Size(0, 91);
            this.lblTopRight.TabIndex = 2;
            this.lblTopRight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMiddleLeft
            // 
            this.lblMiddleLeft.AutoSize = true;
            this.lblMiddleLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMiddleLeft.Location = new System.Drawing.Point(147, 115);
            this.lblMiddleLeft.Name = "lblMiddleLeft";
            this.lblMiddleLeft.Size = new System.Drawing.Size(0, 91);
            this.lblMiddleLeft.TabIndex = 3;
            this.lblMiddleLeft.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblMiddleMiddle
            // 
            this.lblMiddleMiddle.AutoSize = true;
            this.lblMiddleMiddle.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMiddleMiddle.Location = new System.Drawing.Point(259, 115);
            this.lblMiddleMiddle.Name = "lblMiddleMiddle";
            this.lblMiddleMiddle.Size = new System.Drawing.Size(0, 91);
            this.lblMiddleMiddle.TabIndex = 4;
            // 
            // lblMiddleRight
            // 
            this.lblMiddleRight.AutoSize = true;
            this.lblMiddleRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMiddleRight.Location = new System.Drawing.Point(372, 115);
            this.lblMiddleRight.Name = "lblMiddleRight";
            this.lblMiddleRight.Size = new System.Drawing.Size(0, 91);
            this.lblMiddleRight.TabIndex = 5;
            // 
            // lblBottomLeft
            // 
            this.lblBottomLeft.AutoSize = true;
            this.lblBottomLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBottomLeft.Location = new System.Drawing.Point(147, 215);
            this.lblBottomLeft.Name = "lblBottomLeft";
            this.lblBottomLeft.Size = new System.Drawing.Size(0, 91);
            this.lblBottomLeft.TabIndex = 6;
            // 
            // lblBottomMiddle
            // 
            this.lblBottomMiddle.AutoSize = true;
            this.lblBottomMiddle.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBottomMiddle.Location = new System.Drawing.Point(259, 215);
            this.lblBottomMiddle.Name = "lblBottomMiddle";
            this.lblBottomMiddle.Size = new System.Drawing.Size(0, 91);
            this.lblBottomMiddle.TabIndex = 7;
            // 
            // lblBottomRight
            // 
            this.lblBottomRight.AutoSize = true;
            this.lblBottomRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBottomRight.Location = new System.Drawing.Point(372, 215);
            this.lblBottomRight.Name = "lblBottomRight";
            this.lblBottomRight.Size = new System.Drawing.Size(0, 91);
            this.lblBottomRight.TabIndex = 8;
            // 
            // lblTopMiddle
            // 
            this.lblTopMiddle.AutoSize = true;
            this.lblTopMiddle.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTopMiddle.Location = new System.Drawing.Point(259, 9);
            this.lblTopMiddle.Name = "lblTopMiddle";
            this.lblTopMiddle.Size = new System.Drawing.Size(0, 91);
            this.lblTopMiddle.TabIndex = 9;
            this.lblTopMiddle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnNewGame
            // 
            this.btnNewGame.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnNewGame.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewGame.Location = new System.Drawing.Point(207, 418);
            this.btnNewGame.Name = "btnNewGame";
            this.btnNewGame.Size = new System.Drawing.Size(128, 32);
            this.btnNewGame.TabIndex = 10;
            this.btnNewGame.Text = "New Game";
            this.btnNewGame.UseVisualStyleBackColor = false;
            this.btnNewGame.Click += new System.EventHandler(this.btnNewGame_Click);
            // 
            // lblGameResult
            // 
            this.lblGameResult.AutoSize = true;
            this.lblGameResult.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGameResult.Location = new System.Drawing.Point(235, 357);
            this.lblGameResult.Name = "lblGameResult";
            this.lblGameResult.Size = new System.Drawing.Size(0, 24);
            this.lblGameResult.TabIndex = 11;
            // 
            // Tic_Tac_Toe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(608, 511);
            this.Controls.Add(this.lblGameResult);
            this.Controls.Add(this.btnNewGame);
            this.Controls.Add(this.lblTopMiddle);
            this.Controls.Add(this.lblBottomRight);
            this.Controls.Add(this.lblBottomMiddle);
            this.Controls.Add(this.lblBottomLeft);
            this.Controls.Add(this.lblMiddleRight);
            this.Controls.Add(this.lblMiddleMiddle);
            this.Controls.Add(this.lblMiddleLeft);
            this.Controls.Add(this.lblTopRight);
            this.Controls.Add(this.lblTopLeft);
            this.Name = "Tic_Tac_Toe";
            this.Text = "Tic Tac Toe";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTopLeft;
        private System.Windows.Forms.Label lblTopRight;
        private System.Windows.Forms.Label lblMiddleLeft;
        private System.Windows.Forms.Label lblMiddleMiddle;
        private System.Windows.Forms.Label lblMiddleRight;
        private System.Windows.Forms.Label lblBottomLeft;
        private System.Windows.Forms.Label lblBottomMiddle;
        private System.Windows.Forms.Label lblBottomRight;
        private System.Windows.Forms.Label lblTopMiddle;
        private System.Windows.Forms.Button btnNewGame;
        private System.Windows.Forms.Label lblGameResult;
    }
}

