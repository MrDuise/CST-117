﻿//Michael Duisenberg
//11-22-20
//CST-117
//This program creates a tic-tac-toe game using a 2-D array
//This is all my own code


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOCA_4_Tic_Tac_Toe
{
    public partial class Tic_Tac_Toe : Form
    {
        public Tic_Tac_Toe()
        {
            InitializeComponent();
        }


        /// <summary>
        /// this method checks the value of each label to find the winner
        /// </summary>
       public void checkGame()
        {
            string winner = "";
            bool tie = false;
            if ((lblTopLeft.Text == lblTopMiddle.Text) && (lblTopMiddle.Text == lblTopRight.Text))//top row
                winner = lblTopLeft.Text;
            else if ((lblMiddleLeft.Text == lblMiddleMiddle.Text) && (lblMiddleMiddle.Text == lblMiddleRight.Text))//middle row
                winner = lblMiddleLeft.Text;
            else if ((lblBottomLeft.Text == lblBottomMiddle.Text) && (lblBottomMiddle.Text == lblBottomRight.Text))//bottom row
                winner = lblBottomLeft.Text;

            else if ((lblTopLeft.Text == lblMiddleLeft.Text) && (lblMiddleLeft.Text == lblBottomLeft.Text))//first coloum
                winner = lblTopLeft.Text;
            else if ((lblTopMiddle.Text == lblMiddleMiddle.Text) && (lblMiddleMiddle.Text == lblBottomMiddle.Text))//middle coloum
                winner = lblTopMiddle.Text;
            else if ((lblTopRight.Text == lblMiddleRight.Text) && (lblMiddleRight.Text == lblBottomRight.Text))//right coloum
                winner = lblTopRight.Text;

            else if ((lblTopLeft.Text == lblMiddleMiddle.Text) && (lblMiddleMiddle.Text == lblBottomRight.Text))//diangonal going to the right
                winner = lblTopLeft.Text;
            else if ((lblTopRight.Text == lblMiddleMiddle.Text) && (lblMiddleMiddle.Text == lblBottomLeft.Text))//diangonal going to the left
                winner = lblTopRight.Text;
            else
                tie = true;

            
            lblGameResult.Text = "The Winner is " + winner + "!!";
            

            if(tie)
            {
                lblGameResult.Text = "The game was a Tie!";
            }

        }
        /// <summary>
        /// Button method. The following code is excuated when the New Game Button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNewGame_Click(object sender, EventArgs e)
        {
            //create variables
            const int ROWS = 3;
            const int COLS = 3;
            int[,] newGame = new int[ROWS, COLS];//array for holding the numbers
            string[,] newGameResult = new string[ROWS, COLS];//array for holding the string values X or O
            Random rand = new Random();

            for(int a = 0; a < ROWS; a++)
            {
                for(int b = 0; b < COLS; b++)
                {
                    newGame[a, b] = rand.Next(2);//creates a random number between 0 and 2, then loads it into the array

                    if (newGame[a, b] == 1)
                        newGameResult[a, b] = "X";
                    else
                        newGameResult[a, b] = "O";
                    
                }
            }

            //top row
            lblTopLeft.Text = newGameResult[0, 0];
            lblTopMiddle.Text = newGameResult[0, 1];
            lblTopRight.Text = newGameResult[0, 2];

            //middle row
            lblMiddleLeft.Text = newGameResult[1, 0];
            lblMiddleMiddle.Text = newGameResult[1, 1];
            lblMiddleRight.Text = newGameResult[1, 2];

            //bottom row
            lblBottomLeft.Text = newGameResult[2, 0];
            lblBottomMiddle.Text = newGameResult[2, 1];
            lblBottomRight.Text = newGameResult[2, 2];

            checkGame();//calls the checkGame method
            

        }
    }
}
