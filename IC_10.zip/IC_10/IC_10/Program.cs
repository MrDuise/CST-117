﻿//Michael Duisenberg
//Wrote this code in class

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BuisnessLogic;

namespace IC_10
{
    class Program
    {
        static void Main(string[] args)
        {
            //read in a text file
            //ManageTextFile newContent = new ManageTextFile("IC_10.txt", @"C:\Users\lovez\Desktop");
            ManageTextFile newContent = new ManageTextFile("IC_10.txt", Directory.GetCurrentDirectory() + @"\DataFile");
            string fileContent = newContent.passingFileContent();

            //now parse out the string and return the matches
            ParseString getCount = new ParseString(fileContent);
            int numWords = getCount.getWordCount();
            Console.WriteLine("There are {0} words that end in t or e", numWords);
            Console.ReadLine();

            //------------------------
            //define our array
            TwoDimArray newArrayContent = new TwoDimArray();
            int[,] arrNew = newArrayContent.createArray();

            //get the string and print it using foreach loop

            Console.WriteLine("Array Contents: {0}", newArrayContent.readArray(arrNew));
            Console.ReadLine();
        }
    }
}
