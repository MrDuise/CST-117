﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;


//this is the buisness logic layer
//this code process the data 
namespace BuisnessLogic
{
   public class ParseString
    {
        //define attributes
        private bool isWord;
        public int wordCount { get; private set; }
        public string strToParse { get; private set; }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="strToParse"></param>
        public ParseString( string strToParse)
        {
            this.isWord = false;
            this.wordCount = 0;
            this.strToParse = strToParse;
        }

        /// <summary>
        /// removes all punctuation from the string
        /// </summary>
        /// <param name="fileContentsVal"></param>
        /// <returns></returns>
        private string parsePunctuation(string fileContentsVal)
        {
            //we are stripping out the punctuation

            string strResults = Regex.Replace(fileContentsVal, @"[^\w\d\s]", "");

            return (strResults);//typically would do this in one line.
        }

        public int getWordCount()
        {
            string fileContents = "";
            
            //the first thing is to remove the punctation
            fileContents = parsePunctuation(strToParse);

            //get all the words in the array
            string[] arrIndWords = parseWords(fileContents);

            //iterate through the array and detect last char

            foreach (string word in arrIndWords)
            {
                //now we will determine if word ends in t or e
                if(wordDetector(word))
                {
                    wordCount++;
                }

            }
            return (wordCount);

        }

        private bool wordDetector(string word)
        {
            //reset the bool to false
            isWord = false;
            //so we can test in lower case only
            word = word.ToLower();
            //get the last char of word
            char lastChar = word.Last();
            //test the char
            if(lastChar == 't' || lastChar == 'e')
            {
                isWord = true;
            }
            return isWord;
        }


        private string[] parseWords(string strToParse)
        {
            //define a 1D array with referense varaible called arrWord
            string[] arrWord = strToParse.Split();
            return arrWord;
        }

    }
}
