﻿using System;
using System.IO;
using DataAccess;


//this is the buisness logic layer
//this code process the data 
namespace BuisnessLogic
{
    public class ManageTextFile
    {
        //define our attributes
        private string textFileName;
        private string fileDirectory;
        private string fullDirLocation;

        //delcare reference variable so we can use it in the different methods
        //this is not instanting the class or reating an instance of the class, it is a placeholder
        ReadTextFile passingData;





        
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="textFileName"></param>
        /// <param name="fileDirectory"></param>
        public ManageTextFile(string textFileName, string fileDirectory)
        {
            this.textFileName = textFileName;
            this.fileDirectory = fileDirectory;
            fullDirLocation = fileDirectory + @"\" + textFileName;
            //create an instance of the class and execute the constructor
            passingData = new ReadTextFile();
        }

        /// <summary>
        /// pass the contents of the text file
        /// </summary>
        /// <returns></returns>
        public string passingFileContent()
        {
            //pass the file contents from data access layer to presentation layer
            return (passingData.getFileContents(fullDirLocation));
        }


       

    }
}
