﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuisnessLogic
{
    public class TwoDimArray
    {

        //define the reference variable
        int[,] intArray;

        /// <summary>
        /// 2D Initializer
        /// </summary>
        /// <returns></returns>
        public int[,] twoDInitalizer()
        {
            intArray = new int[3, 4]
            {
                {1, 0, 12, -1 },
                {7, -3, 2, 5 },
                {-5, -2, 2, 9 }
            };

            return (intArray);
        }


        /// <summary>
        /// create a 2D array with nested for loops
        /// </summary>
        /// <returns></returns>
        public int[,] createArray()
        {
            //populate a 2D array
            //define the size of the array

            int[,] arrAutoCreate = new int[3, 4];
            //Counter
            int counter = 0;

            //nested For Loops
            //outer loop interate through the rows
            //int rows is the inititalizer 
            //conditions
            //row++ iterator
            for(
                int rows = 0; rows < arrAutoCreate.GetLength(0); rows++)
            {
                for(int cols = 0; cols < arrAutoCreate.GetLength(1); cols++)
                {
                    //insert integer into array
                    arrAutoCreate[rows, cols] = counter;
                    //Inc counter
                    counter++;
                }
            }
            return (arrAutoCreate);
        }


        public string readArray(int[,] arrToRead)
        {
            //define the string to return
            string contentsOfArray = "";
            //iterate through the array
            foreach (int element in arrToRead)
            {
                //inseret array contents into string
                contentsOfArray += string.Format("{0} ", element);
            }
            return (contentsOfArray);
        }
    }
}
