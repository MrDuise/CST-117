﻿//Michael Duisenberg
//CST-117
//11-23-2020
//This is code that I wrote in class

using System;
using System.IO;


//This is the data access layer
//this layer is the one that touches the data
namespace DataAccess
{
    public class ReadTextFile
    {
        //define the attributes
        public string fileContents { get; private set; }


        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="fileContents"></param>
        public ReadTextFile()
        {
            //set to empty
            fileContents = "";
        }

        /// <summary>
        /// this method reads the file and returns a string that contains the contents of that file
        /// </summary>
        /// <param name="fullDirLocation"></param>
        /// <returns></returns>
        public string getFileContents(string fullDirLocation)
        {

            //read in the text file
            using (StreamReader file = new StreamReader(fullDirLocation))
            {
                fileContents = file.ReadToEnd();
            }
            return (fileContents);
        }
    }
}
