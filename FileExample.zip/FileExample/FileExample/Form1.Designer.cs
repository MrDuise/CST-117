﻿namespace FileExample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dialogFileOpen = new System.Windows.Forms.OpenFileDialog();
            this.btnReadFile = new System.Windows.Forms.Button();
            this.rtbExample1 = new System.Windows.Forms.RichTextBox();
            this.rtbExample3 = new System.Windows.Forms.RichTextBox();
            this.rtbExample2 = new System.Windows.Forms.RichTextBox();
            this.rtbExample4 = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // dialogFileOpen
            // 
            this.dialogFileOpen.DefaultExt = "\"txt\"";
            this.dialogFileOpen.FileName = "openFileDialog1";
            this.dialogFileOpen.InitialDirectory = "@\"C:\\\"";
            // 
            // btnReadFile
            // 
            this.btnReadFile.Location = new System.Drawing.Point(46, 394);
            this.btnReadFile.Name = "btnReadFile";
            this.btnReadFile.Size = new System.Drawing.Size(124, 23);
            this.btnReadFile.TabIndex = 0;
            this.btnReadFile.Text = "Read File";
            this.btnReadFile.UseVisualStyleBackColor = true;
            this.btnReadFile.Click += new System.EventHandler(this.btnReadFile_Click);
            // 
            // rtbExample1
            // 
            this.rtbExample1.Location = new System.Drawing.Point(12, 12);
            this.rtbExample1.Name = "rtbExample1";
            this.rtbExample1.Size = new System.Drawing.Size(756, 79);
            this.rtbExample1.TabIndex = 1;
            this.rtbExample1.Text = "";
            // 
            // rtbExample3
            // 
            this.rtbExample3.Location = new System.Drawing.Point(12, 198);
            this.rtbExample3.Name = "rtbExample3";
            this.rtbExample3.Size = new System.Drawing.Size(756, 75);
            this.rtbExample3.TabIndex = 2;
            this.rtbExample3.Text = "";
            // 
            // rtbExample2
            // 
            this.rtbExample2.Location = new System.Drawing.Point(12, 107);
            this.rtbExample2.Name = "rtbExample2";
            this.rtbExample2.Size = new System.Drawing.Size(756, 85);
            this.rtbExample2.TabIndex = 3;
            this.rtbExample2.Text = "";
            // 
            // rtbExample4
            // 
            this.rtbExample4.Location = new System.Drawing.Point(12, 279);
            this.rtbExample4.Name = "rtbExample4";
            this.rtbExample4.Size = new System.Drawing.Size(756, 76);
            this.rtbExample4.TabIndex = 4;
            this.rtbExample4.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rtbExample4);
            this.Controls.Add(this.rtbExample2);
            this.Controls.Add(this.rtbExample3);
            this.Controls.Add(this.rtbExample1);
            this.Controls.Add(this.btnReadFile);
            this.Name = "Form1";
            this.Text = "Reading a text file";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog dialogFileOpen;
        private System.Windows.Forms.Button btnReadFile;
        private System.Windows.Forms.RichTextBox rtbExample1;
        private System.Windows.Forms.RichTextBox rtbExample3;
        private System.Windows.Forms.RichTextBox rtbExample2;
        private System.Windows.Forms.RichTextBox rtbExample4;
    }
}

