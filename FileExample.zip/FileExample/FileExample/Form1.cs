﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FileExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Button to read in a file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReadFile_Click(object sender, EventArgs e)
        {
            //get the filename
            if (this.dialogFileOpen.ShowDialog() == DialogResult.OK)
            {
                string textFile = this.dialogFileOpen.FileName;
                //get the path of the file plus the file name
                string dirLocation = Path.GetFullPath(dialogFileOpen.FileName);

                //we need to remove the filename from the dirLocation so lets work on 
                //manipulation of strings
                //first we will find the last location of "\\"
                int index = dirLocation.LastIndexOf("\\");
                //so now lets remove the filename
                string finalDirLocation = dirLocation.Remove(index, dirLocation.Length - index);
                //-------------------
                //example 1 write file
                //create a string array
                string[] writeLines = { "First Line", "Second Line", "Third Line" };
                //write to file
                File.WriteAllLines(finalDirLocation + "\\Writelines.txt", writeLines);


                //--------------------------
                //example 2 write file
                string textWrite = "A class is the most important data type in C#.";
                //WriteAllText creates a file, writes the specified string to the file
                File.WriteAllText(finalDirLocation + "\\WriteTestString.txt", textWrite);


                //----------------------------
                //example 3 write file
                using (StreamWriter file = new StreamWriter(finalDirLocation + "\\WriteLines.txt", true))
                {
                    file.WriteLine("Fourth Line");
                }


                

                //=============================

                //File Class
                if (File.Exists(textFile))
                {
                    //Read entire text file content in one string
                    string text = File.ReadAllText(textFile);
                    this.rtbExample1.Text = text;
                }

                if(File.Exists(textFile))
                {
                    //read a text file line by line
                    string[] lines = File.ReadAllLines(textFile);
                    foreach (string line in lines)
                    {
                        this.rtbExample2.Text += line + "\n";
                    }
                }

                //===========================

                //third example
                //streamerreader
                //initialize a strearmreater to the selected file

                StreamReader sr = new StreamReader(textFile);
                //display the file contents
                string allText = sr.ReadToEnd();
                this.rtbExample3.Text = allText;


                //second streamereader example
                if(File.Exists(textFile))
                {
                    //read file use streamreader. read file line by line
                    using (StreamReader file = new StreamReader(textFile))
                    {
                        int counter = 0;
                        string ln;
                        while((ln = file.ReadLine()) != null)
                        {
                            this.rtbExample4.Text = allText;
                            counter++;
                        }
                        
                        this.rtbExample4.Text += ("\nFile has {0} lines.", counter);//string arguement
                    }
                }



                //------------------
                //split example

                string[] words = allText.Split(); 
                foreach(string word in words)
                {
                    string individualWord = word;
                }


                //lowercase or uppercase
                string lowerCase = words[3].ToLower();
                string upperCase = words[3].ToUpper();





            }
            
            


        }
    }
}
