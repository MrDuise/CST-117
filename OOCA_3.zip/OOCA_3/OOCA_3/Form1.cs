﻿//Michael Duisenberg
//CST-117
//10-17-20
//Out of class assignment 3
//This program allows the user to select a file, then it processes that file, then it writes the data that it processed to a new file
//this program is my own code and logic, except for the writeLine sections, this was taken from the information covered in class


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOCA_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void fileOpen_FileOk(object sender, CancelEventArgs e)
        {
           
        }

        
       
        /// <summary>
        /// this section is the main body of the program. When the user clicks the button, a open file dialog opens, user selects a text file, then the file is processed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnDisplayValues_Click(object sender, EventArgs e)
        {

            StreamReader stringInputFile;//variable that file gets read to
            string longestWord = "I";
            string testString;
           
            if (fileOpen.ShowDialog() == DialogResult.OK)
            {
                stringInputFile = File.OpenText(fileOpen.FileName);
                string fileText = this.fileOpen.FileName;//used for opening file into an array
                string dirLocation = Path.GetFullPath(fileOpen.FileName);//gets full path of the file being opened
                int index = dirLocation.LastIndexOf("\\");
                int counter = 0;
                string[] writeLines = new string[50];
                //so now lets remove the filename
                string finalDirLocation = dirLocation.Remove(index, dirLocation.Length - index);

                while (!stringInputFile.EndOfStream)//while the end of the file has not been reached
                {
                    testString = stringInputFile.ReadLine();//read first file of file into string
                    

                    lstBoxLowerCase.Items.Add(testString.ToLower());//read each line of the file into the list bow and convert the string to lowercase

                    writeLines[counter] = testString.ToLower(); //turns all the lines in the file lower case and then adds them to an array
                    if (testString.Length > longestWord.Length)//if the test string is longer than the defualt longest string, the string gets replaced
                        longestWord = testString;

                    counter++;
                }
                txtLongestWord.Text = longestWord;//print longest word to text box
                writeLines[counter] = longestWord;//add longest word to writeLines array
                counter += 1;


                //checks if the file exists, reads the file into a array line by line, then sorts the array
                if (File.Exists(fileText))
                {
                    //read a text file line by line
                    string[] lines = File.ReadAllLines(fileText);

                    Array.Sort(lines);

                    int last = lines.GetUpperBound(0);//finds the index of the last array element
                   
                   
                    txtWordsFirstLastAbl.Text = lines[0] + " " + lines[last];  //prints the first array element and the last array element

                    writeLines[counter] = lines[0];
                    counter++;
                    writeLines[counter] = lines[last];
                    counter++;
                    
                }

                //checks for vowels in each word of the file
                if(File.Exists(fileText))
                {
                    string mostVowels = "I";

                    int vowelCounter = 0;

                    string[] vowels = { "a", "e", "i", "o", "u" };//array of vowels
                    string[] lines2 = File.ReadAllLines(fileText);
                    int last2 = lines2.GetUpperBound(0);
                    int[] vowelsCounter3 = new int[lines2.GetUpperBound(0) + 1];//array to hold the number of vowels to compare

                    for (int linesCounter = 0; linesCounter <= last2; linesCounter++)//loops through the lines array
                    {
                        for(int vowelCounter2 = 0; vowelCounter2 <= vowels.GetUpperBound(0);vowelCounter2++)//loops through the vowels array
                        {
                            //if the current line in lines arry contains the current letter in the vowels array
                            if (lines2[linesCounter].ToLower().Contains(vowels[vowelCounter2]))
                            {
                                vowelCounter++;
                            }
                            
                        }
                        vowelsCounter3[linesCounter] = vowelCounter;//load the vowelCounter into the array to store them for comparision
                        if(vowelCounter >= vowelsCounter3[linesCounter])
                        {
                            mostVowels = lines2[linesCounter];
                        }
                        vowelCounter = 0;
                    }

                    txtMostVowels.Text = mostVowels;
                    writeLines[counter] = mostVowels;

                }

                
                //write to file
                File.WriteAllLines(finalDirLocation + "\\Writelines.txt", writeLines);



            }
        }
    }
}
