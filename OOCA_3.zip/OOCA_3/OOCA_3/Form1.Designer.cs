﻿namespace OOCA_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fileOpen = new System.Windows.Forms.OpenFileDialog();
            this.txtMostVowels = new System.Windows.Forms.TextBox();
            this.txtLongestWord = new System.Windows.Forms.TextBox();
            this.txtWordsFirstLastAbl = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnDisplayValues = new System.Windows.Forms.Button();
            this.lstBoxLowerCase = new System.Windows.Forms.ListBox();
            this.fileSaveDialog = new System.Windows.Forms.SaveFileDialog();
            this.SuspendLayout();
            // 
            // fileOpen
            // 
            this.fileOpen.FileOk += new System.ComponentModel.CancelEventHandler(this.fileOpen_FileOk);
            // 
            // txtMostVowels
            // 
            this.txtMostVowels.Location = new System.Drawing.Point(267, 289);
            this.txtMostVowels.Name = "txtMostVowels";
            this.txtMostVowels.Size = new System.Drawing.Size(274, 22);
            this.txtMostVowels.TabIndex = 3;
            // 
            // txtLongestWord
            // 
            this.txtLongestWord.Location = new System.Drawing.Point(267, 225);
            this.txtLongestWord.Name = "txtLongestWord";
            this.txtLongestWord.Size = new System.Drawing.Size(274, 22);
            this.txtLongestWord.TabIndex = 4;
            // 
            // txtWordsFirstLastAbl
            // 
            this.txtWordsFirstLastAbl.Location = new System.Drawing.Point(267, 175);
            this.txtWordsFirstLastAbl.Name = "txtWordsFirstLastAbl";
            this.txtWordsFirstLastAbl.Size = new System.Drawing.Size(274, 22);
            this.txtWordsFirstLastAbl.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "All words to lower case:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 289);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(209, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "The Word with the most Vowels:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 228);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "The Longest Word is: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 178);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(227, 17);
            this.label4.TabIndex = 9;
            this.label4.Text = "First and Last Word Alphabetically:";
            // 
            // btnDisplayValues
            // 
            this.btnDisplayValues.Location = new System.Drawing.Point(12, 370);
            this.btnDisplayValues.Name = "btnDisplayValues";
            this.btnDisplayValues.Size = new System.Drawing.Size(107, 64);
            this.btnDisplayValues.TabIndex = 11;
            this.btnDisplayValues.Text = "Display values";
            this.btnDisplayValues.UseVisualStyleBackColor = true;
            this.btnDisplayValues.Click += new System.EventHandler(this.btnDisplayValues_Click);
            // 
            // lstBoxLowerCase
            // 
            this.lstBoxLowerCase.FormattingEnabled = true;
            this.lstBoxLowerCase.ItemHeight = 16;
            this.lstBoxLowerCase.Location = new System.Drawing.Point(267, 12);
            this.lstBoxLowerCase.Name = "lstBoxLowerCase";
            this.lstBoxLowerCase.Size = new System.Drawing.Size(202, 116);
            this.lstBoxLowerCase.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lstBoxLowerCase);
            this.Controls.Add(this.btnDisplayValues);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtWordsFirstLastAbl);
            this.Controls.Add(this.txtLongestWord);
            this.Controls.Add(this.txtMostVowels);
            this.Name = "Form1";
            this.Text = "File Sorter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog fileOpen;
        private System.Windows.Forms.TextBox txtMostVowels;
        private System.Windows.Forms.TextBox txtLongestWord;
        private System.Windows.Forms.TextBox txtWordsFirstLastAbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnDisplayValues;
        private System.Windows.Forms.ListBox lstBoxLowerCase;
        private System.Windows.Forms.SaveFileDialog fileSaveDialog;
    }
}

